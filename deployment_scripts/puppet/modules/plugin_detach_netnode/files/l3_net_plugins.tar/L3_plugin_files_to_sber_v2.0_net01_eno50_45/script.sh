#!/bin/bash


dpkg -l | grep quagga || dpkg -i quagga_0.99.22.4-3ubuntu1_amd64.deb

cp quagga.py /usr/lib/python2.7/dist-packages/neutron/agent/linux/

cp quagga.filters  /etc/neutron/rootwrap.d/

cp ospfd_idz.conf /etc/quagga/

cp ospfd_ipz.conf /etc/quagga/

cp quagga.conf.template /etc/neutron/

cp /usr/lib/python2.7/dist-packages/neutron/agent/l3/agent.py /usr/lib/python2.7/dist-packages/neutron/agent/l3/agent.py_back

grep "from neutron.agent.linux import quagga" /usr/lib/python2.7/dist-packages/neutron/agent/l3/agent.py  || sed -i "44i from neutron.agent.linux import quagga" /usr/lib/python2.7/dist-packages/neutron/agent/l3/agent.py
grep "return quagga.QuaggaRouter" /usr/lib/python2.7/dist-packages/neutron/agent/l3/agent.py ||  sed -i s/return\ legacy_router.LegacyRouter/return\ quagga.QuaggaRouter/ /usr/lib/python2.7/dist-packages/neutron/agent/l3/agent.py
sed -i s/from\ oslo.config/from\ oslo_config/ /usr/lib/python2.7/dist-packages/neutron/agent/linux/quagga.py

cp /usr/share/doc/quagga/examples/zebra.conf.sample /etc/quagga/zebra.conf

cp ospfd.conf /etc/quagga/

mkdir /var/run/neutron-quagga
chown neutron:neutron /var/run/neutron-quagga

grep "\[quagga\]" /etc/neutron/neutron.conf || echo "[quagga]" >> /etc/neutron/neutron.conf
grep "vty_password=Mirantis01" /etc/neutron/neutron.conf || echo "vty_password=Mirantis01" >> /etc/neutron/neutron.conf

