mkdir /var/run/neutron-quagga
chown neutron:neutron /var/run/neutron-quagga

grep "\[quagga\]" /etc/neutron/neutron.conf || echo "[quagga]" >> /etc/neutron/neutron.conf
grep "vty_password=Mirantis01" /etc/neutron/neutron.conf || echo "vty_password=Mirantis01" >> /etc/neutron/neutron.conf

cp ospfd_idz.conf /etc/quagga/

cp ospfd_ipz.conf /etc/quagga/


ip route add 10.127.38.99/32  via 10.124.2.62
ip route add 10.127.32.66/32  via 10.124.2.62




## add vlan which is not created by Neutron
ip link add link bond0 name bond0.2706 type vlan id 2706
ip link set  bond0.2706 up


ovs-vsctl add-br br-idz
ip netns add br-idz-namespace

## veth pair internal
ip link add name br-idz-int type veth peer name br-idz-ns

##add one veth port to namespace
ip link set br-idz-ns netns br-idz-namespace

## add second veth to bridge
ovs-vsctl add-port br-idz br-idz-int

## set interfaces UP
ip netns exec br-idz-namespace ip link set dev br-idz-ns up
ip link set br-idz-int up
ip netns exec br-idz-namespace ip link set dev lo up

sed -i s/^#bridge_mappings\ =$/bridge_mappings\ =physnet2:br-idz,physnet3:br-ipz/ /etc/neutron/plugins/ml2/openvswitch_agent.ini

sleep 10

ip netns exec br-idz-namespace ip addr add 10.116.63.225/27 dev br-idz-ns

brctl addbr br-idz-ex
brctl addif br-idz-ex bond0.2706

## veth pair external
ip link add name br-idz2-ex type veth peer name br-idz2-ex-ns

## set vethpair between namespace and out external linux bridge
ip link set br-idz2-ex-ns netns br-idz-namespace
brctl addif br-idz-ex br-idz2-ex

ip netns exec br-idz-namespace ip link set dev br-idz2-ex-ns up
ip link set br-idz2-ex up

## address for for amun32 - first network node
#ip addr add 10.116.62.40/27 dev br-idz-ex
ip netns exec br-idz-namespace ip addr add 10.116.62.140/27 dev br-idz2-ex-ns

## disable default Public bridge br-ex
ip link set br-ex down

## bring our bridge up
ip link set br-idz-ex up

#crm resource restart clone_neutron-l3-agent
#crm resource restart clone_neutron-openvswitch-agent

####
#### Setup IPZ
####

ovs-vsctl add-br br-ipz


ip link add link bond0 name bond0.2806 type vlan id 2806
ip link set  bond0.2806 up
#


ip link add name br-ipz-int type veth peer name br-ipz-ns
ip netns add br-ipz-namespace
ip link set br-ipz-ns netns br-ipz-namespace

#ovs-vsctl add-br br-ipz
ovs-vsctl add-port br-ipz br-ipz-int

ip netns exec br-ipz-namespace ip link set dev br-ipz-ns up
ip link set br-ipz-int up
ip netns exec br-ipz-namespace ip link set dev lo up
sleep 10
ip netns exec br-ipz-namespace  ip addr add 10.117.63.225/27 dev br-ipz-ns

brctl addbr br-ipz-ex
brctl addif br-ipz-ex bond0.2806

## veth pair external
ip link add name br-ipz2-ex type veth peer name br-ipz2-ex-ns
ip link set br-ipz2-ex-ns netns br-ipz-namespace
brctl addif br-ipz-ex br-ipz2-ex

ip netns exec br-ipz-namespace ip link set dev br-ipz2-ex-ns up
ip link set br-ipz2-ex up

## address for for amun32 - first network node
#ip addr add 10.117.62.40/27 dev br-ipz-ex
ip netns exec br-ipz-namespace ip addr add 10.117.62.140/27 dev br-ipz2-ex-ns

## disable default Public bridge br-ex
ip link set br-ex down

## bring our bridge up
ip link set br-ipz-ex up

ip netns exec br-idz-namespace ip link set dev br-idz-ns mtu 9000
ip netns exec br-ipz-namespace ip link set dev br-ipz-ns mtu 9000


##for testing
#crm resource restart clone_neutron-l3-agent
#crm resource restart clone_neutron-openvswitch-agent

ip netns exec br-idz-namespace /usr/lib/quagga/zebra -d -f /etc/quagga/zebra.conf -A 127.0.0.1 -i /tmp/idz.pid.zebra -z /tmp/idz.zebra.api
ip netns exec br-idz-namespace /usr/lib/quagga/ospfd -d -f /etc/quagga/ospfd_idz.conf -A 127.0.0.1 -i /tmp/idz.pid.ospfd -z /tmp/idz.zebra.api

ip netns exec br-ipz-namespace /usr/lib/quagga/zebra -d -f /etc/quagga/zebra.conf -A 127.0.0.1 -i /tmp/ipz.pid.zebra -z /tmp/ipz.zebra.api
ip netns exec br-ipz-namespace /usr/lib/quagga/ospfd -d -f /etc/quagga/ospfd_ipz.conf -A 127.0.0.1 -i /tmp/ipz.pid.ospfd -z /tmp/ipz.zebra.api

/etc/init.d/neutron-server restart
/etc/init.d/neutron-dhcp-agent restart
/etc/init.d/neutron-l3-agent restart
/etc/init.d/neutron-metadata-agent restart
/etc/init.d/neutron-openvswitch-agent restart
sleep 10
/etc/init.d/neutron-server restart



