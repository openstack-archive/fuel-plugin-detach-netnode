grep "\[quagga\]" /etc/neutron/neutron.conf || echo "[quagga]" >> /etc/neutron/neutron.conf
grep "vty_password=Mirantis01" /etc/neutron/neutron.conf || echo "vty_password=Mirantis01" >> /etc/neutron/neutron.conf

cp ospfd_idz.conf /etc/quagga/

cp ospfd_ipz.conf /etc/quagga/



echo "post-up ip route add 10.127.38.67/32  via 10.124.2.94  | true # 10.127.38.67/32" >> /etc/network/interfaces.d/ifcfg-br-mgmt
echo "post-up ip route add 10.127.38.99/32  via 10.124.2.94  | true # 10.127.38.99/32" >> /etc/network/interfaces.d/ifcfg-br-mgmt
echo "post-up ip route add 10.127.32.66/32  via 10.124.2.94  | true # 10.127.32.66/32" >> /etc/network/interfaces.d/ifcfg-br-mgmt


sed -i s/^#bridge_mappings\ =$/bridge_mappings\ =physnet2:br-idz,physnet3:br-ipz/ /etc/neutron/plugins/ml2/openvswitch_agent.ini



cat << EOT_bond2706 > /etc/network/interfaces.d/ifcfg-bond0.2706
auto bond0.2706
iface bond0.2706 inet manual
vlan-raw-device bond0
EOT_bond2706

cat << EOT_bond2806 > /etc/network/interfaces.d/ifcfg-bond0.2806
auto bond0.2806
iface bond0.2806 inet manual
vlan-raw-device bond0
EOT_bond2806





cat << EOT_br-idz > /etc/network/interfaces.d/ifcfg-br-idz
auto br-idz
allow-ovs br-idz
iface br-idz inet manual
ovs_type OVSBridge
ovs_ports br-idz-int
EOT_br-idz

cat << EOT_br-idz-ex > /etc/network/interfaces.d/ifcfg-br-idz-ex
auto br-idz-ex
iface br-idz-ex inet static
bridge_ports bond0.2706 br-idz2-ex
EOT_br-idz-ex


cat << EOT_br-ipz > /etc/network/interfaces.d/ifcfg-br-ipz
auto br-ipz
allow-ovs br-ipz
iface br-ipz inet manual
ovs_type OVSBridge
ovs_ports br-ipz-int
EOT_br-ipz

cat << EOT_br-ipz-ex > /etc/network/interfaces.d/ifcfg-br-ipz-ex
auto br-ipz-ex
iface br-ipz-ex inet static
bridge_ports bond0.2806 br-ipz2-ex
EOT_br-ipz-ex



cat << EOT_quagga_neutron > /etc/init/quagga_neutron.conf
description     "Custom Quagga upstart script"
author          "Andrey Yurtaykin"


start on runlevel [2345]
stop on starting rc RUNLEVEL=[016]

script
        mkdir -p /var/run/neutron-quagga
        chown neutron:neutron /var/run/neutron-quagga

        logger "added state dir"

        ip link set  bond0.2706 up
        ip netns add br-idz-namespace
        ip link add name br-idz-int type veth peer name br-idz-ns
        ip link set br-idz-ns netns br-idz-namespace
        ip netns exec br-idz-namespace ip link set dev br-idz-ns up
        ip link set br-idz-int up
        ip netns exec br-idz-namespace ip link set dev lo up
        ip netns exec br-idz-namespace ip addr add 10.116.63.225/27 dev br-idz-ns
        ip link add name br-idz2-ex type veth peer name br-idz2-ex-ns
        ip link set br-idz2-ex-ns netns br-idz-namespace
#        brctl addif br-idz-ex br-idz2-ex
        ip netns exec br-idz-namespace ip link set dev br-idz2-ex-ns up
        ip link set br-idz2-ex up
        ip netns exec br-idz-namespace ip addr add 10.116.62.40/27 dev br-idz2-ex-ns
        ip link set br-ex down
        ip link set br-idz-ex up


        ip netns exec br-idz-namespace ip link set dev br-idz-ns mtu 9000

        logger "idz network setup complete"


        ip link set  bond0.2806 up
        ip netns add br-ipz-namespace
        ip link add name br-ipz-int type veth peer name br-ipz-ns
        ip link set br-ipz-ns netns br-ipz-namespace
        ip netns exec br-ipz-namespace ip link set dev br-ipz-ns up
        ip link set br-ipz-int up
        ip netns exec br-ipz-namespace ip link set dev lo up
        ip netns exec br-ipz-namespace ip addr add 10.117.63.225/27 dev br-ipz-ns
        ip link add name br-ipz2-ex type veth peer name br-ipz2-ex-ns
        ip link set br-ipz2-ex-ns netns br-ipz-namespace
#        brctl addif br-ipz-ex br-ipz2-ex
        ip netns exec br-ipz-namespace ip link set dev br-ipz2-ex-ns up
        ip link set br-ipz2-ex up
        ip netns exec br-ipz-namespace ip addr add 10.117.62.40/27 dev br-ipz2-ex-ns
        ip link set br-ex down
        ip link set br-ipz-ex up
        ip netns exec br-ipz-namespace ip link set dev br-ipz-ns mtu 9000
        logger "ipz network setup complete"


        logger "Starting Neutron_quagga for idz network"
        ip netns exec br-idz-namespace /usr/lib/quagga/zebra -d -f /etc/quagga/zebra.conf -A 127.0.0.1 -i /tmp/idz.pid.zebra -z /tmp/idz.zebra.api
        ip netns exec br-idz-namespace /usr/lib/quagga/ospfd -d -f /etc/quagga/ospfd_idz.conf -A 127.0.0.1 -i /tmp/idz.pid.ospfd -z /tmp/idz.zebra.api
        logger "Starting Neutron_quagga for ipz network"
        ip netns exec br-ipz-namespace /usr/lib/quagga/zebra -d -f /etc/quagga/zebra.conf -A 127.0.0.1 -i /tmp/ipz.pid.zebra -z /tmp/ipz.zebra.api
        ip netns exec br-ipz-namespace /usr/lib/quagga/ospfd -d -f /etc/quagga/ospfd_ipz.conf -A 127.0.0.1 -i /tmp/ipz.pid.ospfd -z /tmp/ipz.zebra.api


end script


EOT_quagga_neutron

